<nav class="navbar navbar-expand navbar-light bg-light">
    <a href="index.php" class="navbar-brand ms-3">Home</a>
    <ul class="navbar-nav ms-auto">

        <li class="navitem"><a href="login.php" class="nav-link">Login</a> </li>
        <li class="navitem"><a href="register.php" class="nav-link">Register</a></li>

    </ul>
</nav>