<?php include "components/head.php"; ?>
<title>Login or Register</title>

<body>
  <?php include "components/navbar.php"; ?>
  <div class="container mt-3">

    <div class="mt-4 p-3 bg-primary text-white rounded">
      <h1 style="text-align: center;">Login or register to continue to our site</h1>

    </div>
  </div>




</body>

</html>