<?php 
$conn=mysqli_connect('localhost','root','','web_shop');


